import type { EmployeeStatus } from "../../features/employees/types";

interface Props {
    status: EmployeeStatus;
}

const statusMap = {
    Working: { label: "Đang làm việc", color: "green" },
    Off: { label: "Nghỉ", color: "gray" },
    Inactive: { label: "Không hoạt động", color: "red" },
} as const;

export default function StatusBadge({ status }: Props) {
    const config = statusMap[status];

    return (
        <span
            style={{
                padding: "4px 8px",
                borderRadius: 12,
                background: config.color,
                color: "white",
                fontSize: 12,
            }}
        >
            {config.label}
        </span>
    );
}