export const adminMenu = [
    { label: "Dashboard", path: "/" },
    { label: "Nhân viên", path: "/employees" },
    { label: "Điểm danh", path: "/attendance" },
];