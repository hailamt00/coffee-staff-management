import { Outlet } from 'react-router-dom'
import { Link } from 'react-router-dom'
import { adminMenu } from "./menu";

export default function AdminLayout() {
    return (
        <div style={{ display: "flex", minHeight: "100vh" }}>
            <aside style={{ width: 240, background: "#f3f4f6", padding: 16 }}>
            {adminMenu.map((item) => (
                <div key={item.path}>
                    <Link to={item.path}>{item.label}</Link>
                </div>
            ))}
            </aside>

            <main style={{ flex: 1, padding: 24 }}>
                <Outlet />
            </main>
        </div>
    )
}
