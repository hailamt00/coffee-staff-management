import type { Employee } from "../../features/employees/types";
import { employeesMock } from "../../features/employees/api/employee.mock";

export const employeeService = {
    getAll: async (): Promise<Employee[]> => {
        // Simulate an API call with a delay
        return new Promise((resolve) => {
            setTimeout(() => resolve(employeesMock), 500);
        });
    },
};