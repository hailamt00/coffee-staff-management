import { axiosClient } from "../../../shared/services/api";

export const authApi = {
  login: (data: { username: string; password: string }) =>
    axiosClient.post("/auth/login", data),
};
