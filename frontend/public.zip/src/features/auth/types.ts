export interface User {
  id: number;
  name: string;
  role: "admin" | "staff";
}

export interface AuthState {
  user: User | null;
  token: string | null;
}
