export default function DashboardPage() {
    return <h1>Dashboard</h1>;
}