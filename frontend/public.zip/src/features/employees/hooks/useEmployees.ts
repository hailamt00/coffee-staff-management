import { useQuery } from "@tanstack/react-query";
import { employeeApi } from "../api/employee.api";

export const useEmployees = () => {
    return useQuery({
        queryKey: ["employees"],
        queryFn: employeeApi.getList,
    });
}