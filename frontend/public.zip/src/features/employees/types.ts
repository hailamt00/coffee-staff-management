export type EmployeeStatus = "Working" | "Off" | "Inactive";

export interface Employee {
    id: number;
    name: string;
    position: string;
    status: EmployeeStatus;
}