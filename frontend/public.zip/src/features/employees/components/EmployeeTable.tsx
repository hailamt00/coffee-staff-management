import type { Employee } from "../types";
import StatusBadge from "../../../shared/components/StatusBadge";

interface Props {
    data: Employee[];
}

export default function EmployeeTable({ data }: Props) {
    return (
        <table width="100%" border={1} cellPadding={8}>
            <thead>
                <tr>
                    <th>Tên</th>
                    <th>Vị trí</th>
                    <th>Trạng thái</th>
                </tr>
            </thead>
            <tbody>
                {data.map((e) => (
                    <tr key={e.id}>
                        <td>{e.name}</td>
                        <td>{e.position}</td>
                        <td><StatusBadge status={e.status} /></td>
                    </tr>
                ))}
            </tbody>
        </table >
    );
}