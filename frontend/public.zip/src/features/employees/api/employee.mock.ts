import type { Employee } from "../types";

export const employeesMock: Employee[] = [
    {
        id: 1,
        name: "Nguyễn Văn A",
        position: "Barista",
        status: "Working",
    },
    {
        id: 2,
        name: "Trần Thị B",
        position: "Cashier",
        status: "Off",
    },
];