import { employeesMock } from "./employee.mock";
import type { Employee } from "../types";

export const employeeApi = {
    getList: async (): Promise<Employee[]> => {
        return new Promise((resolve) => {
            setTimeout(() => resolve(employeesMock), 500);
        });
    },
};