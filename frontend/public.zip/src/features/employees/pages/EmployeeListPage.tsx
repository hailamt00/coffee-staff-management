import { useEmployees } from "../hooks/useEmployees";
import EmployeeTable from "../components/EmployeeTable";

export default function EmployeeListPage() {
    const { data, isLoading } = useEmployees();


    if (isLoading) return <p>Loading...</p>

    return (
        <div>
            <h1>Danh sách nhân viên</h1>
            {data && <EmployeeTable data={data} />}
        </div>
    );
}