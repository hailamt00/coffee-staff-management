import QrScanner from "../components/QrScanner";
import { useAttendance } from "../hooks/useAttendance";

export default function AttendancePage() {
    const { data, check, isChecking } = useAttendance();

    const handleScan = (text: string) => {
        //Giả sử QR = "1|Nguyễn Văn A"
        const [id, name] = text.split("|");

        check({
            employeeId: Number(id),
            employeeName: name,
            type: "Check-in",
        });
    };

    return (
        <div>
            <h1>Điểm danh</h1>

            <QrScanner onScanSuccess={handleScan} />

            <h2>Lịch sử</h2>
            <ul>
                {data?.map((r) => (
                    <li key={r.id}>
                        {r.employeeName} - {r.type} - {new Date(r.time).toLocaleString()}
                    </li>
                ))}
            </ul>

            {isChecking && <p>Đang ghi nhận...</p>}
        </div>
    );
}