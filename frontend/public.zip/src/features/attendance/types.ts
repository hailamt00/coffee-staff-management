export type AttendanceType = "Check-in" | "Check-out";

export interface AttendanceRecord {
    id: number;
    employeeId: number;
    employeeName: string;
    type: AttendanceType;
    time: string; // ISO string
}

export interface AttendanceCheckInput {
  employeeId: number;
  employeeName: string;
  type: AttendanceType;
}