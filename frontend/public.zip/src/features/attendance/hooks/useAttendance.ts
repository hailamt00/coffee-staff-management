import { useMutation, useQuery } from "@tanstack/react-query";
import { attendanceApi } from "../api/attendance.api";

export const useAttendance = () => {
    const listQuery = useQuery({
        queryKey: ["attendance"],
        queryFn: attendanceApi.getList,
    });

    const checkMutation = useMutation({
        mutationFn: attendanceApi.check,
        onSuccess: () => {
            listQuery.refetch();
        },
    });

    return {
        ...listQuery,
        check: checkMutation.mutate,
        isChecking: checkMutation.isPending,
    };
};
