import type { AttendanceRecord } from "../types";

export const attendanceMock: AttendanceRecord[] = [];