import type { AttendanceCheckInput, AttendanceRecord } from "../types";

export const attendanceApi = {
    check: async (
        input: AttendanceCheckInput
    ): Promise<AttendanceRecord> => {
        return new Promise((resolve) => {
            const record: AttendanceRecord = {
                id: Date.now(),
                employeeId: input.employeeId,
                employeeName: input.employeeName,
                type: input.type,
                time: new Date().toISOString(),
            };

            setTimeout(() => resolve(record), 500);
        });
    },

    getList: async (): Promise<AttendanceRecord[]> => {
        return []
        },
};