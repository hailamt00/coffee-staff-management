import { useEffect } from "react";
import { Html5Qrcode } from "html5-qrcode";

interface Props {
  onScanSuccess: (text: string) => void;
}

export default function QrScanner({ onScanSuccess }: Props) {
  useEffect(() => {
    let scanner: Html5Qrcode | null = null;

    const startScan = async () => {
      scanner = new Html5Qrcode("qr-scanner");

      await scanner.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: 250 },
        (decodedText) => {
          onScanSuccess(decodedText);
          scanner?.stop();
        },
        () => {}
      );
    };

    startScan();

    return () => {
      scanner?.stop().catch(() => {});
    };
  }, [onScanSuccess]);

  return <div id="qr-scanner" style={{ width: 300 }} />;
}
