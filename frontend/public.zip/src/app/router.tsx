import { createBrowserRouter } from "react-router-dom";

import RequireAuth from '../features/auth/components/RequireAuth';
import LoginPage from '../features/auth/pages/LoginPage'

import AdminLayout from "../shared/components/layout/AdminLayout";
import DashboardPage from "../features/dashboard/pages/DashboardPage";
import EmployeeListPage from "../features/employees/pages/EmployeeListPage";
import AttendancePage from "../features/attendance/pages/AttendancePage";

export const router = createBrowserRouter([
    {
        path: "/login",
        element: <LoginPage />
    },
    {
        element: <RequireAuth />,
        children: [
            {
                path: "/",
                element: <AdminLayout />,
                children: [
                    { index: true, element: <DashboardPage /> },
                    { path: "employees", element: <EmployeeListPage /> },
                    { path: "attendance", element: <AttendancePage /> },
                ],
            },
        ],
    },
]);