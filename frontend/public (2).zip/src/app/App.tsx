import { Outlet } from 'react-router-dom'
import { Layout } from '@/shared/components/Layout'
import { GlobalLoadingSpinner } from '@/shared/components/GlobalLoadingSpinner'
import { useSelector } from 'react-redux'
import { RootState } from './store'
import { NotificationContainer } from '@/shared/components/NotificationContainer'

function App() {
  const globalLoading = useSelector(
    (state: RootState) => state.ui.globalLoading
  )

  return (
    <>
      <Layout>
        <Outlet />
      </Layout>
      {globalLoading && <GlobalLoadingSpinner />}
      <NotificationContainer />
    </>
  )
}

export { App }
