import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export default function DashboardPage() {
  return (
    <div className="grid grid-cols-3 gap-4">
      <Card>
        <CardHeader>
          <CardTitle>Total Staff</CardTitle>
        </CardHeader>
        <CardContent className="text-3xl font-bold">
          24
        </CardContent>
      </Card>
    </div>
  )
}
