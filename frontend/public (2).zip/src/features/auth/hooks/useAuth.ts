import { useMutation } from '@tanstack/react-query'
import { useDispatch } from 'react-redux'
import { loginApi, LoginRequest } from '../api/auth.api'
import { loginSuccess } from '../slices/authSlice'

export const useLogin = () => {
  const dispatch = useDispatch()

  return useMutation({
    mutationFn: (data: LoginRequest) => loginApi.login(data),
    onSuccess: (data) => {
      dispatch(
        loginSuccess({
          user: data.user,
          token: data.token,
          refreshToken: data.refreshToken,
        })
      )
    },
  })
}
