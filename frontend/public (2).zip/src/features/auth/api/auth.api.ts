import axios from '@/shared/api/axios'

export interface LoginRequest {
  username: string
  password: string
}

export interface LoginResponse {
  token: string
  refreshToken: string
  user: {
    id: string
    username: string
    role: 'Admin'
  }
}

export const loginApi = async (data: LoginRequest) => {
  const res = await axios.post<LoginResponse>(
    '/auth/login',
    data
  )
  return res.data
}
