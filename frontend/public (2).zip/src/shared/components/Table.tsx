import React from 'react'
import {
  Table as TablePrimitive,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/shared/components/ui/table'
import { Loader2 } from 'lucide-react'

export interface Column<T> {
  key: keyof T | string
  title: string
  render?: (value: any, record: T, index: number) => React.ReactNode
  width?: string
  align?: 'left' | 'center' | 'right'
}

interface TableProps<T> {
  data: T[]
  columns: Column<T>[]
  loading?: boolean
  emptyMessage?: string
  onRowClick?: (record: T, index: number) => void
  className?: string
}

export function Table<T extends Record<string, any>>({
  data,
  columns,
  loading = false,
  emptyMessage = 'No data available',
  onRowClick,
  className = '',
}: TableProps<T>) {
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <div className="text-sm text-gray-500">Loading...</div>
      </div>
    )
  }

  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="text-sm text-gray-500">{emptyMessage}</div>
      </div>
    )
  }

  return (
    <div className={`rounded-md border ${className}`}>
      <TablePrimitive>
        <TableHeader>
          <TableRow>
            {columns.map((column, index) => (
              <TableHead
                key={index}
                style={{ width: column.width }}
                className={
                  column.align === 'center'
                    ? 'text-center'
                    : column.align === 'right'
                      ? 'text-right'
                      : 'text-left'
                }
              >
                {column.title}
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((record, rowIndex) => (
            <TableRow
              key={rowIndex}
              className={onRowClick ? 'cursor-pointer hover:bg-gray-50' : ''}
              onClick={() => onRowClick?.(record, rowIndex)}
            >
              {columns.map((column, colIndex) => {
                const keyPath = String(column.key)
                const value = keyPath.includes('.')
                  ? keyPath
                      .split('.')
                      .reduce<any>(
                        (obj, key) => (obj as any)?.[key],
                        record as any
                      )
                  : (record as any)[keyPath]

                return (
                  <TableCell
                    key={colIndex}
                    className={
                      column.align === 'center'
                        ? 'text-center'
                        : column.align === 'right'
                          ? 'text-right'
                          : 'text-left'
                    }
                  >
                    {column.render
                      ? column.render(value, record, rowIndex)
                      : value}
                  </TableCell>
                )
              })}
            </TableRow>
          ))}
        </TableBody>
      </TablePrimitive>
    </div>
  )
}
