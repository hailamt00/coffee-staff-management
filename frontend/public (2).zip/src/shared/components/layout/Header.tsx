import { Button } from '@/components/ui/button'
import { useDispatch } from 'react-redux'
import { logout } from '@/features/auth/slices/authSlice'

export default function Header() {
  const dispatch = useDispatch()

  return (
    <header className="h-14 border-b px-6 flex items-center justify-between">
      <span className="font-semibold">Admin Dashboard</span>
      <Button
        variant="outline"
        size="sm"
        onClick={() => dispatch(logout())}
      >
        Logout
      </Button>
    </header>
  )
}
