import { Button } from '@/components/ui/button'

export default function Sidebar() {
  return (
    <aside className="w-64 border-r p-4">
      <h2 className="font-bold mb-6">ADMIN</h2>
      <Button variant="ghost" className="w-full justify-start">
        Dashboard
      </Button>
    </aside>
  )
}
