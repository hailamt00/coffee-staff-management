import React, { useState } from 'react'
import { ArrowLeft, ArrowRight, ChevronDown } from 'lucide-react'

interface PaginationProps {
  page: number
  perPage: number
  total: number
  onPageChange: (page: number) => void
  onPerPageChange?: (perPage: number) => void
  pageSizeOptions?: number[]
}

export const Pagination: React.FC<PaginationProps> = ({
  page,
  perPage,
  total,
  onPageChange,
  onPerPageChange,
  pageSizeOptions = [10, 20, 50, 100],
}) => {
  const [showDropdown, setShowDropdown] = useState(false)
  const totalPages = Math.ceil(total / perPage)

  const getPageNumbers = () => {
    const pages: (number | string)[] = []

    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i)
    } else {
      if (page <= 4) {
        pages.push(1, 2, 3, 4, 5, '...', totalPages)
      } else if (page >= totalPages - 3) {
        pages.push(
          1,
          '...',
          totalPages - 4,
          totalPages - 3,
          totalPages - 2,
          totalPages - 1,
          totalPages
        )
      } else {
        pages.push(1, '...', page - 1, page, page + 1, '...', totalPages)
      }
    }

    return pages
  }

  const handlePerPageChange = (newPerPage: number) => {
    if (onPerPageChange) {
      onPerPageChange(newPerPage)
      onPageChange(1)
    }
    setShowDropdown(false)
  }

  return (
    <div className="flex flex-col items-center justify-between gap-4 border-t border-gray-200 bg-white px-4 py-3 sm:flex-row sm:px-6">
      {/* Info & Page Size Selector */}
      <div className="flex w-full items-center gap-4 sm:w-auto">
        <p className="text-sm text-gray-600">
          <span className="font-medium text-gray-900">
            {(page - 1) * perPage + 1}
          </span>
          {' - '}
          <span className="font-medium text-gray-900">
            {Math.min(page * perPage, total)}
          </span>
          {' of '}
          <span className="font-medium text-gray-900">{total}</span>
        </p>

        {onPerPageChange && (
          <div className="relative">
            <button
              onClick={() => setShowDropdown(!showDropdown)}
              className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-sm text-gray-700 transition-all duration-200 hover:bg-gray-50"
            >
              <span>{perPage} / page</span>
              <ChevronDown className="h-4 w-4" />
            </button>

            {showDropdown && (
              <>
                <div
                  className="fixed inset-0 z-[100]"
                  onClick={() => setShowDropdown(false)}
                />
                <div className="absolute bottom-full left-0 z-[101] mb-2 max-h-48 w-28 overflow-auto rounded-lg border border-gray-200 bg-white shadow-xl">
                  {pageSizeOptions.map((size) => (
                    <button
                      key={size}
                      onClick={() => handlePerPageChange(size)}
                      className={`w-full px-4 py-2 text-left text-sm transition-colors ${
                        size === perPage
                          ? 'bg-blue-600 text-white'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      {size} / page
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex items-center gap-1">
        {/* Previous Button */}
        <button
          onClick={() => page > 1 && onPageChange(page - 1)}
          disabled={page <= 1}
          className="flex h-9 w-9 items-center justify-center rounded-lg border text-gray-500 transition-all duration-200 hover:bg-gray-100 hover:text-blue-600 disabled:opacity-40 disabled:hover:bg-transparent disabled:hover:text-gray-500"
          aria-label="Previous page"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>

        {/* Page Numbers */}
        <div className="hidden items-center gap-1 sm:flex">
          {getPageNumbers().map((p, i) =>
            p === '...' ? (
              <span
                key={`ellipsis-${i}`}
                className="flex h-9 w-9 items-center justify-center text-sm text-gray-400"
              >
                ...
              </span>
            ) : (
              <button
                key={`page-${p}`}
                onClick={() => onPageChange(p as number)}
                className={`flex h-9 w-9 items-center justify-center rounded-lg border text-sm font-medium transition-all duration-200 ${
                  p === page
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20'
                    : 'text-gray-700 hover:bg-gray-50 hover:text-blue-600'
                }`}
              >
                {p}
              </button>
            )
          )}
        </div>

        {/* Mobile Page Indicator */}
        <div className="flex items-center rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-sm text-gray-700 sm:hidden">
          {page} / {totalPages}
        </div>

        {/* Next Button */}
        <button
          onClick={() => page < totalPages && onPageChange(page + 1)}
          disabled={page >= totalPages}
          className="flex h-9 w-9 items-center justify-center rounded-lg border text-gray-500 transition-all duration-200 hover:bg-gray-100 hover:text-blue-600 disabled:opacity-40 disabled:hover:bg-transparent disabled:hover:text-gray-500"
          aria-label="Next page"
        >
          <ArrowRight className="h-4 w-4" />
        </button>
      </nav>
    </div>
  )
}
