// Common API response types
export interface ApiResponse<T> {
  data: T
  message?: string
  success: boolean
}

export interface ApiResponseError {
  message?: string
  success: boolean
  errors?: Record<string, string[]>
}

export interface PaginatedResponse<T> {
  data: T[]
  meta: {
    current_page: number
    per_page: number
    total: number
    last_page: number
    from: number
    to: number
  }
  links: {
    first: string
    last: string
    prev: string | null
    next: string | null
  }
}

export interface PaginationParams {
  page?: number
  per_page?: number
  search?: string
}

// Auth types
export interface LoginRequest {
  username: string
  password: string
  client_id?: string
  client_secret?: string
  scope?: string
}

export interface LoginResponse {
  access_token: string
  refresh_token: string
  token_type: string
  expires_in: number
  user: {
    id: string
    username: string
    email: string
    name?: string
    phone?: string
    address?: string
  }
}

export interface RefreshTokenRequest {
  refresh_token: string
  client_id?: string
  client_secret?: string
}

export interface ChangePasswordRequest {
  current_password: string
  password: string
  password_confirmation: string
}

// Product types
export interface Product {
  id: string
  name: string
  slug: string
  description: string
  category_id: string
  category?: Category
  is_active: boolean
  is_public: boolean
  created_at: string
  updated_at: string
  skus: ProductSKU[]
}

export interface CreateProductRequest {
  name: string
  slug: string
  description: string
  category_id: string
  is_active: boolean
  is_public: boolean
}

export interface UpdateProductRequest {
  name?: string
  slug?: string
  description?: string
  is_active?: boolean
}

export interface ProductListParams extends PaginationParams {
  is_active?: boolean
  category_id?: string
}

// SKU types
export interface ProductSKU {
  id: string
  product_id: string
  product?: Product
  sku: string
  price: number
  stock: number
  attributes: Record<string, any>
  is_active: boolean
  is_public: boolean
  created_at: string
  updated_at: string
}

export interface CreateSKURequest {
  product_id: string
  sku: string
  price: number
  stock: number
  attributes: Record<string, any>
  is_active: boolean
  is_public: boolean
}

export interface UpdateSKURequest {
  price?: number
  stock?: number
  is_active?: boolean
}

export interface SKUListParams extends PaginationParams {
  product_id?: string
  is_active?: boolean
  min_price?: number
  max_price?: number
}

// Category types
export interface Category {
  id: string
  name: string
  slug: string
  description: string
  parent_id: string | null
  parent?: Category
  children?: Category[]
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface CreateCategoryRequest {
  name: string
  slug: string
  description: string
  parent_id?: string | null
  is_active: boolean
}

export interface UpdateCategoryRequest {
  name?: string
  slug?: string
  description?: string
  is_active?: boolean
}

// Supplier types
export interface Supplier {
  id: string
  name: string
  code: string
  contact_info: {
    email: string
    phone: string
    address: string
  }
  status: boolean
  created_at: string
  updated_at: string
}

export interface CreateSupplierRequest {
  name: string
  code: string
  contact_info: {
    email: string
    phone: string
    address: string
  }
  status: boolean
}

export interface UpdateSupplierRequest {
  name?: string
  code?: string
  contact_info?: Partial<{
    email: string
    phone: string
    address: string
  }>
  status?: boolean
}

export interface SupplierListParams extends PaginationParams {
  status?: 'active' | 'inactive'
}

// Warehouse types
export interface Warehouse {
  id: string
  name: string
  code: string
  description: string
  address: string
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface CreateWarehouseRequest {
  name: string
  code: string
  description: string
  address: string
  is_active: boolean
}

export interface UpdateWarehouseRequest {
  name?: string
  code?: string
  description?: string
  address?: string
  is_active?: boolean
}

export interface WarehouseListParams extends PaginationParams {
  is_active?: boolean
  location_id?: string
}

// Purchase Order types
export interface PurchaseOrder {
  id: string
  supplier_id: string
  supplier?: Supplier
  warehouse_id: string
  warehouse?: Warehouse
  status: 'draft' | 'pending' | 'confirmed' | 'received' | 'cancelled'
  expected_delivery_date: string
  note?: string
  items: PurchaseOrderItem[]
  created_at: string
  updated_at: string
}

export interface PurchaseOrderItem {
  id: string
  product_sku_id: string
  product_sku?: ProductSKU
  quantity: number
  unit_price: number
  expected_lot_number?: string
  expected_expiry_date?: string
  lot_number?: string
  expiry_date?: string
  manufacture_date?: string
}

export interface CreatePurchaseOrderRequest {
  supplier_id: string
  warehouse_id: string
  expected_delivery_date: string
  note?: string
  items: Array<{
    product_sku_id: string
    quantity: number
    unit_price: number
    expected_lot_number?: string
    expected_expiry_date?: string
  }>
}

export interface UpdatePurchaseOrderRequest {
  expected_delivery_date?: string
  note?: string
  items?: Array<{
    product_sku_id: string
    quantity: number
    unit_price: number
    expected_lot_number?: string
    expected_expiry_date?: string
  }>
}

export interface ReceivePurchaseOrderRequest {
  items: Array<{
    product_sku_id: string
    quantity: number
    unit_price: number
    lot_number: string
    expiry_date: string
    manufacture_date: string
  }>
}

export interface CancelPurchaseOrderRequest {
  cancellation_reason: string
}

export interface PurchaseOrderListParams extends PaginationParams {
  supplier_id?: string
  status?: string
}

// Stock Transaction types
export interface StockTransaction {
  id: string
  type: string
  subtype: string
  warehouse_id: string
  warehouse?: Warehouse
  // Some backends include product at transaction level; keep optional
  product_id?: string
  product?: Product
  quantity?: number
  reference: string
  reference_type?: string
  reference_id: string
  note?: string
  reason?: string
  provider?: string
  created_by?: string
  creator?: User
  user_id?: string
  tenant_id?: string
  business_unit_id?: string
  brand_id?: string
  location_id?: string
  created_at: string
  updated_at: string
  items?: StockTransactionItem[]
}

export interface StockTransactionItem {
  id: string
  stock_transaction_id: string
  product_id: string
  product_sku_id: string
  quantity: number
  tenant_id: string | null
  business_unit_id: string | null
  brand_id: string | null
  location_id: string | null
  unit_price: number | null
  provider: string | null
  supplier_id: string | null
  reference_type: string | null
  reference_id: string | null
  lot_number: string | null
  lot_id: string | null
  expiry_date: string | null
  manufacture_date: string | null
  lot_notes: string | null
  bin_code: string | null
  target_bin_code: string | null
  created_at: string
  updated_at: string
  product?: Product
  product_sku?: ProductSKU
  supplier?: Supplier | null
}

export interface StockTransactionListParams extends PaginationParams {
  date_from?: string
  date_to?: string
  warehouse_id?: string
  product_id?: string
  user_id?: string
  tenant_id?: string
  business_unit_id?: string
  brand_id?: string
  location_id?: string
  type?: 'inbound' | 'outbound'
  subtype?: string
  reference?: string
}

// Galaxy Order types
export interface GalaxyOrder {
  id: string
  warehouse_id: string
  warehouse?: Warehouse
  status: 'pending' | 'processing' | 'completed' | 'cancelled'
  items: GalaxyOrderItem[]
  customer_info: {
    name: string
    phone: string
    email: string
    address: string
  }
  note?: string
  created_at: string
  updated_at: string
}

export interface GalaxyOrderItem {
  id: string
  product_sku_id: string
  product_sku?: ProductSKU
  quantity: number
}

export interface CreateGalaxyOrderRequest {
  warehouse_id: string
  items: Array<{
    product_sku_id: string
    quantity: number
  }>
  customer_info: {
    name: string
    phone: string
    email: string
    address: string
  }
  note?: string
}

export interface User {
  id: string
  name: string
  login_id: string
  is_active: boolean | null
  created_at: string // ISO date
  updated_at: string // ISO date
}

export interface Tenant {
  id: string
  name: string
  code: string
  domain: string
}

export interface BusinessUnit {
  id: string
  name: string
  code: string
}

export interface Brand {
  id: string
  name: string
  code: string
}

export interface Location {
  id: string
  name: string
  code: string
}

export interface TenantContext {
  current_tenant: Tenant
  current_business_unit: BusinessUnit
  current_brand: Brand
  current_location: Location
  available_tenants: Tenant[]
  roles: string[]
  permissions: string[]
}

export interface AuthProfileResponse {
  user: User
  tenant_context: TenantContext
}

// Inventory Adjustment types
export interface InventoryAdjustment {
  id: string
  warehouse_id: string
  warehouse?: Warehouse
  adjustment_type: string
  reason: string
  adjustment_date: string
  reference: string
  note: string
  status:
  | 'draft'
  | 'submitted'
  | 'approved'
  | 'rejected'
  | 'executed'
  | 'cancelled'
  requires_approval: boolean
  items: InventoryAdjustmentItem[]
  created_by?: string
  approved_by?: string
  executed_by?: string
  created_at: string
  updated_at: string
  total_quantity?: number
}

export interface InventoryAdjustmentItem {
  id: string
  product_sku_id: string
  product_sku?: ProductSKU
  lot_number: string
  quantity: number
  new_value: number
  adjustment_reason: string
  bin_code: string
  expiry_date: string
  notes: string
}

export interface CreateInventoryAdjustmentRequest {
  warehouse_id: string
  adjustment_type: string
  reason: string
  adjustment_date: string
  reference: string
  note: string
  requires_approval: boolean
  items: Array<{
    product_sku_id: string
    lot_number: string
    quantity: number
    new_value: number
    adjustment_reason: string
    bin_code: string
    expiry_date: string
    notes: string
  }>
}

export interface UpdateInventoryAdjustmentRequest {
  adjustment_type?: string
  reason?: string
  note?: string
  items?: Array<{
    product_sku_id: string
    quantity: number
    new_value: number
    lot_number: string
    bin_code: string
    notes: string
  }>
}

export interface ApproveInventoryAdjustmentRequest {
  approval_note: string
  auto_execute: boolean
}

export interface InventoryAdjustmentListParams extends PaginationParams {
  warehouse_id?: string
  status?: string
  adjustment_type?: string
  date_from?: string
  date_to?: string
}

export interface InventoryAdjustmentPreview {
  id: string
  warehouse_id: string
  warehouse?: Warehouse
  adjustment_type: string
  reason: string
  adjustment_date: string
  reference: string
  note: string
  status: string
  requires_approval: boolean
  items: InventoryAdjustmentItem[]
  impact_summary: {
    total_items: number
    total_quantity_change: number
    affected_products: number
  }
  created_at: string
  updated_at: string
}

// Product Import types
export interface ExcelImportResult {
  success: boolean
  message: string
  imported: number
  skipped: number
  errors: number
  details?: {
    imported: string[]
    skipped: string[]
    errors: Array<{
      row: number
      error: string
    }>
  }
}

// BcCompany
export interface BcCompanyResponse {
  success: boolean
  data?: Company[]
  meta?: {
    page: number
    per_page: number
    total: number
  }
}
// Company
export interface Company {
  id: string
  bc_id: string
  system_version: string
  timestamp: number
  name: string
  display_name: string
  business_profile_id: string
  system_created_at: string
  system_created_by: string
  system_modified_at: string
  system_modified_by: string
}

// Customer
export interface Customer {
  success: boolean
  data?: {
    id: string
    bc_id: string
    company_id: string
    number: string
    display_name?: string
    type: boolean
    address: {
      line_1: string
      line_2: string
      city: string
      state: string
      country: string
      postal_code: string
    }
    phone_number: string
    email: string
    website: string
    salesperson_code: string
    balance_due: number
    credit_limit: number
    vat: {
      display_name: string
      business_posting_group: string
      tax_registration_number: string
    }
    currency: {
      id: string
      code: string
    }
    payment_terms_id: string
    shipment_method_id: string
    payment_method_id: string
    location: string | null
    blocked: boolean
    last_modified_at: string
  }
  meta?: {
    page: number
    per_page: number
    total: number
  }
}

// BcItem
export interface BcItem {
  success: boolean
  data?: Item[]
  meta?: {
    page: number
    per_page: number
    total: number
  }
}

// Item
export interface Item {
  id: string
  bc_id: string
  company_id: string
  number: string
  display_name?: string
  display_name_2?: string
  type: string
  category: {
    id: string
    code: string
    display_name: string
  }
  blocked: boolean
  gtin: string
  inventory: number
  unit_price: number
  price_includes_tax: boolean
  unit_cost: number
  tax_group: {
    id: string
    code: string
  }
  base_unit_of_measure: string | null
  general_product_posting_group: string | null
  inventory_posting_group: string | null
  picture: string | null
  last_modified_at: string
  deleted_at: string | null
}

// BcItemCategory
export interface BcItemCategory {
  success: boolean
  data?: {
    id: string
    bc_id: string
    company_id: string
    code: string
    parent_category: string
    display_name?: string
    last_modified_at: string
  }
  meta?: {
    page: number
    per_page: number
    total: number
  }
}

// BcSalesPrices
export interface BcSalesPrice {
  success: boolean
  data?: {
    id: string
    bc_id: string
    company_id: string
    price_type: string
    assign_to_type: string
    assign_to: string
    price_list_code: string
    price_list_description: string
    line_no: number
    asset_type: string
    asset_no: string
    asset_id: string
    unit_of_measure_code: string
    unit_price: number
    starting_date: string
    ending_date: string
    minimum_quantity: number
    allow_line_discount: boolean
    allow_invoice_discount: boolean
    item: string | null
    last_modified_at: string
  }
  meta?: {
    page: number
    per_page: number
    total: number
  }
}

// BcItemReferences
export interface BcItemReference {
  success: boolean
  data?: {
    id: string
    bc_id: string
    company_id: string
    reference_no: string
    reference_type: string
    reference_type_no: string
    item_number: string
    variant_code: string
    unit_of_measure: number
    description: string
    starting_date: string
    ending_date: string
    last_modified_at: string
    deleted_at: string | null
  }
  meta?: {
    page: number
    per_page: number
    total: number
  }
}

// BcLocation
export interface BcLocation {
  success: boolean
  data?: {
    id: string
    bc_id: string
    company_id: string
    code: string
    display_name: string
    contact: string
    address_line1: string
    address_line2: string
    city: number
    state: string
    country: string
    postal_code: string
    phone_number: string
    email: string
    website: string
    last_modified_at: string
    deleted_at: string | null
  }
  meta?: {
    page: number
    per_page: number
    total: number
  }
}

// BcVendor
export interface BcVendor {
  success: boolean
  data?: {
    id: string
    bc_id: string
    company_id: string
    number: string
    display_name: string
    address_line1: string
    address_line2: string
    city: number
    state: string
    country: string
    postal_code: string
    phone_number: string
    email: string
    website: string
    tax_registration_number: string
    currency_id: string
    currency_code: string
    irs_1099_code: string
    payment_terms_id: string
    payment_method_id: string
    tax_liable: string
    blocked: string
    balance: number
    last_modified_at: string
    deleted_at: string | null
  }
  meta?: {
    page: number
    per_page: number
    total: number
  }
}

export interface PaginationMeta {
  page: number
  per_page: number
  total: number
}

export interface PaginatedResponses<T> {
  data: T[]
  meta: PaginationMeta
}

// Bill
export interface Bill {
  id: string;
  bill_number: string;
  tran_date: string;
  store_code: string;
  store_name: string;
  customer_number?: string | null;
  customer_name?: string | null;
  tax_registration_id?: string | null;
  ship_address?: string | null;
  description?: string | null;
  amount: string;
  discount_amount: string;
  header_discount_amount: string;
  tax_amount: string;
  total_amount_exclude_tax: string;
  total_amount_include_tax: string;
  customer_type: string;
  external_document_number?: string | null;
  is_closed: boolean;
  detail_status: 'completed' | 'syncing' | string;
  last_detail_synced_at?: string | null;
  ref_id: string;
  ref_type: string;
  bc_id?: string | null;
  bc_doc_number?: string | null;
  bc_status: 'pending' | 'failed' | 'success' | string;
  bc_error?: string | null;
  bc_synced_at?: string | null;
  validation_error?: string | null;
  detail_amount_variance?: string | null;
}

// BillDetail
export interface BillDetail {
  id: string;
  bill_type: string;
  store_number: string;
  line_number: number;
  inventory_number: string;
  bc_item_no?: string | null;
  inventory_name: string;
  uom?: string | null;
  quantity: string;
  sales_price: string;
  discount_rate: string;
  discount_amount: string;
  header_discount_amount: string;
  tax_code?: string | null;
  tax_rate: string;
  tax_amount: string;
  amount_excluding_tax: string;
  amount_including_tax: string;
  ref_id: string;
  ref_type: string;
  tran_date: string;
  external_document_number?: string | null;
  bc_id?: string | null;
  bc_doc_number?: string | null;
  bc_status: 'pending' | 'failed' | 'success' | string;
  bc_error?: string | null;
  bc_synced_at?: string | null;
}

// BillPayment
export interface BillPayment {
  id: string
  payment_number: string
  bc_doc_number?: string | null
  store_number?: string | null
  bill_type?: string | null
  bill_number?: string | null
  tran_date?: string | null
  payment_method?: string | null
  bank_account_number?: string | null
  amount: string
  note?: string | null
  ref_id?: string | null
  ref_type?: string | null
  external_document_number?: string | null
  bc_id?: string | null
  bc_status: 'pending' | 'success' | 'failed' | string
  bc_error?: string | null
  bc_synced_at?: string | null
}

// GroupBill
export interface GroupBill {
  id: string;
  doc_number: string;
  summary_date: string;
  store_number: string;
  bc_customer_number: string;
  customer_type: string;
  bill_type: 'Invoice' | 'Return' | string;
  bill_count: number;
  total_amount_excluding_tax: string;
  total_amount_including_tax: string;
  total_discount_amount: string;
  total_tax_amount: string;
  group_sequence: number;
  bc_id?: string | null;
  bc_doc_number?: string | null;
  bc_status: 'pending' | 'success' | 'failed' | string;
  bc_error?: string | null;
  bc_synced_at?: string | null;
}

// GroupBillDetail
export interface GroupBillDetail {
  id: string;
  grouped_bill_id: string;
  doc_number: string;
  product_code: string;
  bc_item_no?: string | null;
  uom?: string | null;
  sales_price: string;
  total_quantity: number;
  total_amount_excluding_tax: string;
  total_amount_including_tax: string;
  total_discount_amount: string;
  total_tax_amount: string;
  bc_id?: string | null;
  bc_doc_number?: string | null;
  bc_status: 'pending' | 'success' | 'failed' | string;
  bc_error?: string | null;
  bc_synced_at?: string | null;
}

// GroupBillPayment
export interface GroupBillPayment {
  id: string;
  grouped_bill_id: string;
  payment_method: string;
  doc_number: string;
  erp_account?: string | null;
  payment_date: string;
  total_amount: string;
  bc_id?: string | null;
  bc_doc_number?: string | null;
  bc_status: 'pending' | 'success' | 'failed' | string;
  bc_error?: string | null;
  bc_synced_at?: string | null;
}

// ToposBill
export interface ToposBill {
  HoaDonID: string;
  MaHD: string;
  STT: number;
  MaNV: string;
  MaNV2?: string | null;
  MaQuay: string;
  TenQuay: string;
  NgayHD: string;
  NgayBatDau: string;
  NgayKetThuc: string;
  GioBatDau: number;
  GioKetThuc: number;
  CaBan: number;
  DaIn: boolean;
  MaHDGoc: string;
  MaTheKHTT?: string | null;
  MaTheKHSi?: string | null;
  TriGiaBan: string;
  TienCK: string;
  ThanhTienBan: string;
  TienPhuThu: string;
  LoaiHoaDon: number;
  TienTraKhach: string;
  DaCapNhatTon: boolean;
  DaVanChuyen: boolean;
  TrungTamTMThuPhi: boolean;
  F1?: string | null;
  F2?: string | null;
  F3?: string | null;
  F4?: string | null;
  F5?: string | null;
  F6?: string | null;
  F7?: string | null;
  F8?: string | null;
  F9?: string | null;
  F10?: string | null;
  F11?: string | null;
  F12?: string | null;
  F13?: string | null;
  F14?: string | null;
  F15?: string | null;
  F16?: string | null;
  F17?: string | null;
  F18?: string | null;
  F19?: string | null;
  F20?: string | null;
  MaKhachHang?: string | null;
  TenKH?: string | null;
  MaSoThue?: string | null;
  DiaChi?: string | null;
  DienGiai?: string | null;
  MaKho: string;
  TenKho: string;
  MaCH: string;
}

// ToposBillDetail
export interface ToposBillDetail {
  HoaDonID: string;
  HangHoaID: string;
  MaHH: string;
  STT: number;
  LoaiHangHoaBan: number;
  TenHH: string;
  NgayGioQuet: string;
  MaNccDM: string;
  SoLuong: string;
  DGBan: string;
  TriGiaBan: string;
  TLCKGiamGia: string;
  TienGiamGia: string;
  TriGiaSauGiamGia: string;
  TLCK_GioVang: string;
  TienCK_GioVang: string;
  TriGiaSauGioVang: string;
  TLCKHD: string;
  TienCKHD: string;
  TriGiaSauCKHD: string;
  TLCK_TheGiamGia: string;
  TienCK_TheGiamGia: string;
  ThanhTienBan: string;
  TienPhuThu: string;
  VATDauRa: string;
  TriGiaVATDauRa: string;
  DonGiaVonBQ: string;
  TriGiaVonBQ: string;
  DonGiaBQ: string;
  TriGiaBQ: string;
  DaGhiHDTC: boolean;
  DaVanChuyen: boolean;
  LaHangKhuyenMai: boolean;
  DaSuDung: boolean;
  MaGoiNho?: string | null;
  F1?: string | null;
  F2?: string | null;
  F3?: string | null;
  F4?: string | null;
  F5?: string | null;
  F6?: string | null;
  F7?: string | null;
  F8?: string | null;
  F9?: string | null;
  F10?: string | null;
  F11?: string | null;
  F12?: string | null;
  F13?: string | null;
  F14?: string | null;
  F15?: string | null;
  F16?: string | null;
  F17?: string | null;
  F18?: string | null;
  F19?: string | null;
  F20?: string | null;
}

// ToposBillPayment
export interface ToposBillPayment {
  HoaDonID: string;
  MaHinhThuc: string;
  MaNhomThanhToan: string;
  MaThe?: string | null;
  ChuThe?: string | null;
  ThanhTien: string;
  TyGiaNgoaiTe: string;
  ThanhTienQuiDoi: string;
  TLFee: string;
  DaVanChuyen: boolean;
  STT: number;
  F1?: string | null;
  F2?: string | null;
  F3?: string | null;
  F4?: string | null;
  F5?: string | null;
  F6?: string | null;
  F7?: string | null;
  F8?: string | null;
  F9?: string | null;
  F10?: string | null;
  F11?: string | null;
  F12?: string | null;
  F13?: string | null;
  F14?: string | null;
  F15?: string | null;
  F16?: string | null;
  F17?: string | null;
  F18?: string | null;
  F19?: string | null;
  F20?: string | null;
}
