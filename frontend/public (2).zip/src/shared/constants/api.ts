export const API_CONFIG = {
  DEV_BASE_URL: 'http://localhost:81/api/v1',
  PROD_BASE_URL: 'http://101.99.37.229:81/api/v1',
  ENV_VAR_KEY: 'VITE_API_URL',
  TIMEOUT: 60000,
} as const

export const getApiBaseUrl = (): string => {
  const isDev = import.meta.env.DEV
  return isDev
    ? API_CONFIG.DEV_BASE_URL
    : import.meta.env[API_CONFIG.ENV_VAR_KEY] ||
        API_CONFIG.PROD_BASE_URL
}
