public record ShiftInput(
    string Name,
    string StartTime,
    string EndTime,
    bool IsEnabled
);
