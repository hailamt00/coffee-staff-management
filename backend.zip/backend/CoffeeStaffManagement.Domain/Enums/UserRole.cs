namespace CoffeeStaffManagement.Domain.Enums;

public enum UserRole
{
    Admin = 1,
    Staff = 2
}
