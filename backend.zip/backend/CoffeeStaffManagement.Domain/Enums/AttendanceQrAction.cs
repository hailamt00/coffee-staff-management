namespace CoffeeStaffManagement.Domain.Enums;

public enum AttendanceQrAction
{
    CheckIn = 1,
    CheckOut = 2
}