export type Role = {
  id: string
  name: string
  description: string
  usersCount: number
  createdAt: string
}
